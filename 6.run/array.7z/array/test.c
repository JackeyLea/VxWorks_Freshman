#include<vxworks.h> 
#include<stdio.h> 
#include<stdlib.h> 
int test()
{ 
 int i = 1; 
 
 while(1) 
 { 
 printf ("%d\t",i); 
 if(i%10==0&&i!=0) 
 printf("\n"); 
 i++; 
 if(i==101) 
 break; 
 } 
 printf("\n"); 
 return 0; 
}

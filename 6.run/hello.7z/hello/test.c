#include <stdio.h>

int first_test(void)
{
  printf("hello world!\n");
  return 0;
}

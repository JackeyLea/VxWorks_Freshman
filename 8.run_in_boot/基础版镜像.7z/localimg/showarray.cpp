#include <vxworks.h> 
#include <iostream>

using namespace std;

extern "C" void test(){
	int i=1;
	
	while(1){
		cout<<i;
		if(i%10==0 && i!=0){
			cout<<endl;
		}
		i++;
		if(i==101){
			break;
		}
	}
	cout<<endl;
}

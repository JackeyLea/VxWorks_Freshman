#include <stdio.h>

int first_test(char* a)
{
  printf("%s\n",a);
  return 0;
}

/* usrAppInit.c - stub application initialization routine */

/* Copyright (c) 1998,2006 Wind River Systems, Inc. 
 *
 * The right to copy, distribute, modify or otherwise make use
 * of this software may be licensed only pursuant to the terms
 * of an applicable Wind River license agreement.
 */

/*
modification history
--------------------
01b,16mar06,jmt  Add header file to find USER_APPL_INIT define
01a,02jun98,ms   written
*/

/*
DESCRIPTION
Initialize user application code.
*/ 

#include <vxWorks.h>
#if defined(PRJ_BUILD)
#include "prjParams.h"
#endif /* defined PRJ_BUILD */

#include <stdio.h>
#include <taskLib.h>
#include <stdlib.h>
#include <string.h>
#include <symLib.h>
#include <moduleLib.h>
#include <loadLib.h>
#include <fcntl.h>

extern SYMTAB_ID sysSymTbl;/*system symbol table*/

/*****************************************************************************
 * @ find symbol by name, used to load app's main function
 * @ sym_tbl_id - symbol table address, name - symbol name , p_val - save found symtbl, p_type - save found symbol type
*/


/******************************************************************************
 * @ load dynamic library
 * @ filename, the full path of file
 * @ return ok if success, else error
 */

static STATUS _load_module(char* filename){
	int fd;
	MODULE_ID hModule;
	
	/*open app*/
	if((fd=open(filename,0,0664))==ERROR){
		printf("fd = %d\n", fd);
		printf("Cannot open %s(AppRun) file.!\n", filename);
		return ERROR;
	}
	
	/*load all symbol table*/
	hModule = loadModule(fd, LOAD_ALL_SYMBOLS);
	close(fd);
	return OK;
}

/*****************************************************************************
 * @ load app symbol ,merge image and app
 * @ filename - app output filename full path, main_name - app main func
 * @ ok is success
 */
STATUS load_app(char *filename, char* main_name){
	SYM_TYPE p_type;
	FUNCPTR main_func = NULL;
	
	if(_load_module(filename)==ERROR){
		printf("load_module (%s) error\n.",filename);
	}
	
	/*find symbol*/
	STATUS status = symFindByName(sysSymTbl,main_name,(char*)&main_func,&p_type);
	 if (status == ERROR)
	 {
	  printf("symFindByName error\n");
	  return 1;
	 }
	 else
	 {
	  printf("deviceEntry = 0x%x, type = %d\n", (int)main_func, (int)p_type);
	  char* szPara = "test for booting run!";
	  (*main_func)(szPara);
	 }
	
	return OK;
}

/******************************************************************************
*
* usrAppInit - initialize the users application
*/ 

void usrAppInit (void)
    {
#ifdef	USER_APPL_INIT
	USER_APPL_INIT;		/* for backwards compatibility */
#endif
	printf("app run...\n");
	load_app("/ata0a/hello.out","first_test");
    /* add application specific code here */
    }


